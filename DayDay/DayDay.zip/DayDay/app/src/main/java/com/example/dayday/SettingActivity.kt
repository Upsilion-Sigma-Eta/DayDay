package com.example.dayday

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SettingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        // activity_setting.xml에 id가 num인 TextView가 하나 있는데 거기에 알람에서 뜬 랜덤 번호를 표시하겠음.
        // 하지만 아직 숫자를 띄우는데에는 실패함.
        var num = findViewById(R.id.num) as TextView
        num.text = intent.getStringExtra(MainActivity.keyNumber)
    }
}
