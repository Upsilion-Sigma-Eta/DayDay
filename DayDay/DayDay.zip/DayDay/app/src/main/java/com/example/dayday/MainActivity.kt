package com.example.dayday

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Log.INFO
import androidx.core.app.NotificationCompat
import java.io.*
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var notification_builder = NotificationCompat.Builder(this)
            .setSmallIcon(R.drawable.test_image)
            .setContentTitle("알림 제목 입력")
            .setContentText("알림 내용 입력")

        // 오레오 버전 이상부터는 (사실상 현재 쓰이는 폰 대부분이) 채널 정보 필요
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel_id = "TestChannel" // 알림을 받을 채널 id 설정
            val channel_name = "채널이름" // 채널 이름 설정
            val descriptionText = "채널설명글" // 채널 설명글 설정
            val importance = NotificationManager.IMPORTANCE_DEFAULT // 알림 우선순위 설정
            val channel = NotificationChannel(channel_id, channel_name, importance).apply {
                description = descriptionText
            }
        }

        // val로 선언하면서 타입 선언??
        val notificationManager: NotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // ********* 파일 입출력을 통한 노티피케이션 테스트 코드 *********
        val test_file_path = getFilesDir().path + "/testDummy@gmail.com.ics"
        val file_reader = BufferedReader(FileReader(test_file_path))
        val schedule_list = mutableListOf<Schedule>()

        // .ics 파일 파싱 시작
        var line : String = ""

        // 헤더 부분 제거
        for (i: Int in 1..11) {
            line = file_reader.readLine() ?: break
        }

        while (true) {
            line = file_reader.readLine() ?: break
            line = line ?: break

            val schedule_with_weather = Schedule()

            // .ics 파일 파싱 함수 호출 - UID 부분 처리
            schedule_with_weather.parsingWithWeather(line)

            // 일정의 구조에서 총 15개의 항목으로 구성되고, 위에서 UID 부분을 처리했으므로 2번에서 15번까지의 항목 파싱
            for (i: Int in 2..15) {
                // EOF에 도달했을 경우에 루프문을 빠져나감
                line = file_reader.readLine() ?: break

                schedule_with_weather.parsingWithWeather(line)
            }

            // 제대로된 데이터 형식이 아닌 (WEATHER는 NULL일 수 없음) 값은 제외하고 변조 가능한 리스트에 추가
            if (schedule_with_weather.weather != ""){
                schedule_list.add(schedule_with_weather)
            }
        }


        // 파일 리더 닫기
        file_reader.close()

        // 리스트를 순회하면서 알림을 출력
        schedule_list.forEach{
            notification_builder.setContentTitle(it.weather)
            notificationManager.notify(Random.nextInt(), notification_builder.build())
        }


        // ********* 파일 입출력을 통한 노티피케이션 테스트 코드 끝 ***********

        notificationManager.notify(2847261, notification_builder.build())
    }
}